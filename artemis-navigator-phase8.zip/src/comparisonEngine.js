/**
 * Artemis Lunar Landing Site Navigator - Regional Comparison & Weighted Ranking Engine
 * 
 * Round 5 & Round 7 Scientific Implementation:
 * 
 * 1. Multi-Region Time-Series Evaluation (Round 5):
 *    - For all 9 candidate regions over the active simulation span [t0, t0 + span]:
 *      * % of time Sun disc fraction f☉ > 0.0 (any direct solar visibility)
 *      * % of time Sun disc fraction f☉ > 0.5 (majority disc illumination)
 *      * Longest continuous dark period (hours/days with f☉ = 0.0)
 *      * % of time Earth disc fraction f⊕ > 0.0 (direct line-of-sight communications)
 *      * % of time Earth disc fraction f⊕ > 0.5 (majority Earth disc visible)
 *      * Mean slope μ and 95th-percentile slope P95 within the evaluation radius (default 3 km)
 *    - Time-sliced asynchronous computation ensures 60 FPS UI responsiveness without freezing.
 * 
 * 2. Multi-Criteria Weighted Ranking & Normalization (Round 7):
 *    - Criteria Normalization across the 9 candidate regions:
 *      * Solar Illumination Score S_sun in [0, 1]:
 *        Min-max normalized from solar illumination fraction over the span:
 *        S_sun(r) = (val(r) - min_k val(k)) / (max_k val(k) - min_k val(k) + eps)
 *      * Direct-to-Earth Comm Score S_earth in [0, 1]:
 *        Min-max normalized from Earth direct line-of-sight fraction:
 *        S_earth(r) = (val(r) - min_k val(k)) / (max_k val(k) - min_k val(k) + eps)
 *      * Slope Flatness Score S_slope in [0, 1]:
 *        Inverted min-max of 95th-percentile slope (lower slope = safer landing):
 *        S_slope(r) = (max_k P95(k) - P95(r)) / (max_k P95(k) - min_k P95(k) + eps)
 *      * Composite Weighted Score C(r) in [0, 100]:
 *        C(r) = 100 * (w_sun * S_sun + w_earth * S_earth + w_slope * S_slope) / (w_sun + w_earth + w_slope)
 *    - Explicit weight normalization displays actual fractional weight percentages.
 *    - Mandatory Reviewer Disclaimer:
 *      “NASA candidate region selection also weighs science objectives and launch-window flight dynamics, which this geometric tool does not model.”
 */

import { REGIONS } from '../regions.js';
import { CONFIG } from '../config.js';
import { computeEphemeris, computeTopocentricHorizon } from './ephemeris.js';
import { evaluateRegionCelestialOcclusion, getRegionHorizonProfile } from './horizon.js';
import { computeLocalizedSlopeAt, getElevationAt } from './terrain.js';

// Cache of computed comparison datasets by epoch and span
const comparisonCache = new Map();

/**
 * Computes regional comparison telemetry across all 9 candidate regions over [baseEpoch, baseEpoch + spanDays]
 * Uses asynchronous chunking so the browser thread remains responsive.
 * 
 * @param {Date} baseEpoch - Starting UTC Date
 * @param {number} spanDays - Time window duration in days (e.g. 30, 90, 180, 365)
 * @param {number} stepHours - Sampling interval in hours (default 3 hours for high fidelity)
 * @param {number} slopeRadiusKm - Localized slope radius (default 3 km)
 * @param {Function} onProgress - Progress callback (pct: 0 to 100)
 * @returns {Promise<Array<Object>>} Computed statistics for all 9 regions
 */
export async function computeRegionalComparisonData(
  baseEpoch,
  spanDays,
  stepHours = 3,
  slopeRadiusKm = 3.0,
  onProgress = null
) {
  const epochIso = baseEpoch.toISOString().substring(0, 10);
  const cacheKey = `${epochIso}_${spanDays}d_${stepHours}h_${slopeRadiusKm}km`;

  if (comparisonCache.has(cacheKey)) {
    if (onProgress) onProgress(100);
    return comparisonCache.get(cacheKey);
  }

  const numSteps = Math.max(12, Math.floor((spanDays * 24) / stepHours));
  const dtHours = (spanDays * 24) / numSteps;
  const startMs = baseEpoch.getTime();

  // Pre-calculate celestial ephemeris at each time step
  const ephemSteps = [];
  for (let s = 0; s <= numSteps; s++) {
    const tDate = new Date(startMs + s * dtHours * 3600 * 1000);
    ephemSteps.push(computeEphemeris(tDate));
  }

  // Pre-warm horizon profiles and slope stats for each region
  const regionStaticStats = REGIONS.map((reg) => {
    const elevKm = getElevationAt(reg.lat, reg.lon);
    const slope = computeLocalizedSlopeAt(reg.lat, reg.lon, slopeRadiusKm);
    const horizon = getRegionHorizonProfile(reg.id, reg.lat, reg.lon);
    return {
      region: reg,
      elevKm,
      slope,
      horizon,
    };
  });

  const results = [];
  const totalRegions = REGIONS.length;

  for (let rIdx = 0; rIdx < totalRegions; rIdx++) {
    const stat = regionStaticStats[rIdx];
    const reg = stat.region;
    const elevKm = stat.elevKm;

    let sunAbove0Count = 0;
    let sunAbove50Count = 0;
    let earthAbove0Count = 0;
    let earthAbove50Count = 0;

    let currentDarkHours = 0;
    let maxDarkHours = 0;

    // Time-sliced inner sampling loop
    for (let s = 0; s <= numSteps; s++) {
      const ephem = ephemSteps[s];

      // Topocentric horizon directions
      const sunTopo = computeTopocentricHorizon(reg.lat, reg.lon, ephem.subSolarLat, ephem.subSolarLon, 149597870.7, elevKm);
      const earthTopo = computeTopocentricHorizon(reg.lat, reg.lon, ephem.subEarthLat, ephem.subEarthLon, ephem.earthDistanceKm, elevKm);

      // Extended disc occlusions
      const occlusion = evaluateRegionCelestialOcclusion(reg, sunTopo, earthTopo);

      if (occlusion.fSun > 0.0001) {
        sunAbove0Count++;
        currentDarkHours = 0;
      } else {
        currentDarkHours += dtHours;
        if (currentDarkHours > maxDarkHours) {
          maxDarkHours = currentDarkHours;
        }
      }

      if (occlusion.fSun >= 0.50) {
        sunAbove50Count++;
      }

      if (occlusion.fEarth > 0.0001) {
        earthAbove0Count++;
      }

      if (occlusion.fEarth >= 0.50) {
        earthAbove50Count++;
      }
    }

    const totalSamples = numSteps + 1;
    const pctSunAbove0 = (sunAbove0Count / totalSamples) * 100.0;
    const pctSunAbove50 = (sunAbove50Count / totalSamples) * 100.0;
    const pctEarthAbove0 = (earthAbove0Count / totalSamples) * 100.0;
    const pctEarthAbove50 = (earthAbove50Count / totalSamples) * 100.0;
    const maxDarkDays = maxDarkHours / 24.0;

    results.push({
      id: reg.id,
      name: reg.name,
      lat: reg.lat,
      lon: reg.lon,
      source: reg.source,
      source_url: reg.source_url,
      reference_url: reg.reference_url,
      kind: reg.kind,
      status: reg.status,
      elevKm: stat.elevKm,
      meanSlopeDeg: stat.slope.meanSlopeDeg,
      p95SlopeDeg: stat.slope.p95SlopeDeg,
      slopeRadiusKm,
      pctSunAbove0,
      pctSunAbove50,
      maxDarkHours,
      maxDarkDays,
      pctEarthAbove0,
      pctEarthAbove50,
      spanDays,
      sampleCount: totalSamples,
      stepHours: Number(dtHours.toFixed(2)),
    });

    if (onProgress) {
      onProgress(Math.round(((rIdx + 1) / totalRegions) * 100));
    }

    // Yield back to browser microtask queue every 2 regions to maintain 60 FPS
    if (rIdx % 2 === 0) {
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }

  comparisonCache.set(cacheKey, results);
  return results;
}

/**
 * Computes Normalized Criterion Scores and Composite Weighted Ranking (Round 7)
 * 
 * @param {Array<Object>} rawData - Comparison telemetry array from computeRegionalComparisonData
 * @param {Object} weights - { sun: number, earth: number, slope: number } (0 to 100)
 * @returns {Array<Object>} Ranked regional entries with normalized scores and composite score
 */
export function rankRegionsByWeights(rawData, weights = { sun: 40, earth: 40, slope: 20 }) {
  if (!rawData || rawData.length === 0) return [];

  const rawSun = Math.max(0, weights.sun ?? 40);
  const rawEarth = Math.max(0, weights.earth ?? 40);
  const rawSlope = Math.max(0, weights.slope ?? 20);
  const totalWeight = rawSun + rawEarth + rawSlope || 1;

  // Normalized weight fractions (sum to 1.0)
  const normWeightSun = rawSun / totalWeight;
  const normWeightEarth = rawEarth / totalWeight;
  const normWeightSlope = rawSlope / totalWeight;

  // 1. Determine Min & Max bounds across the 9 regions for min-max normalization
  let minSun = Infinity, maxSun = -Infinity;
  let minEarth = Infinity, maxEarth = -Infinity;
  let minSlopeP95 = Infinity, maxSlopeP95 = -Infinity;

  rawData.forEach((item) => {
    if (item.pctSunAbove0 < minSun) minSun = item.pctSunAbove0;
    if (item.pctSunAbove0 > maxSun) maxSun = item.pctSunAbove0;

    if (item.pctEarthAbove0 < minEarth) minEarth = item.pctEarthAbove0;
    if (item.pctEarthAbove0 > maxEarth) maxEarth = item.pctEarthAbove0;

    if (item.p95SlopeDeg < minSlopeP95) minSlopeP95 = item.p95SlopeDeg;
    if (item.p95SlopeDeg > maxSlopeP95) maxSlopeP95 = item.p95SlopeDeg;
  });

  const rangeSun = maxSun - minSun > 0.001 ? maxSun - minSun : 1.0;
  const rangeEarth = maxEarth - minEarth > 0.001 ? maxEarth - minEarth : 1.0;
  const rangeSlope = maxSlopeP95 - minSlopeP95 > 0.001 ? maxSlopeP95 - minSlopeP95 : 1.0;

  // 2. Compute individual normalized scores [0.0, 1.0] and composite score [0, 100]
  const ranked = rawData.map((item) => {
    // Solar Score: higher illumination = better
    const normSunScore = Math.max(0, Math.min(1, (item.pctSunAbove0 - minSun) / rangeSun));

    // Earth LoS Score: higher direct visibility = better
    const normEarthScore = Math.max(0, Math.min(1, (item.pctEarthAbove0 - minEarth) / rangeEarth));

    // Slope Flatness Score: lower slope = safer = higher score (inverse min-max)
    const normSlopeScore = Math.max(0, Math.min(1, (maxSlopeP95 - item.p95SlopeDeg) / rangeSlope));

    // Weighted composite score in [0.0, 100.0]
    const compositeScore = (
      normWeightSun * normSunScore +
      normWeightEarth * normEarthScore +
      normWeightSlope * normSlopeScore
    ) * 100.0;

    return {
      ...item,
      normSunScore: Number(normSunScore.toFixed(3)),
      normEarthScore: Number(normEarthScore.toFixed(3)),
      normSlopeScore: Number(normSlopeScore.toFixed(3)),
      compositeScore: Number(compositeScore.toFixed(2)),
      weightsMeta: {
        rawSun,
        rawEarth,
        rawSlope,
        totalWeight,
        normWeightSun: Number(normWeightSun.toFixed(3)),
        normWeightEarth: Number(normWeightEarth.toFixed(3)),
        normWeightSlope: Number(normWeightSlope.toFixed(3)),
      },
    };
  });

  // Sort descending by composite score by default
  ranked.sort((a, b) => b.compositeScore - a.compositeScore);

  // Assign 1-indexed ranks
  ranked.forEach((item, index) => {
    item.rank = index + 1;
  });

  return ranked;
}
