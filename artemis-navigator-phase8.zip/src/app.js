/**
 * Artemis Lunar Landing Site Navigator - Main App Bootstrap
 * 
 * Round 2 Orchestrator:
 * 1. Synchronizes single authoritative timeStore
 * 2. Drives astronomy-engine ephemeris calculation for every simTime tick
 * 3. Coordinates view mode transitions: Orrery vs South Pole 3D View
 * 4. Connects candidate region selections, pin raycasting, hover tooltips, and camera docking
 */

import { timeStore } from './timeStore.js';
import { computeEphemeris, computeTopocentricHorizon } from './ephemeris.js';
import { evaluateRegionCelestialOcclusion, prewarmRegionHorizonProfiles, getRegionHorizonProfile, DEFAULT_MAST_HEIGHT_M } from './horizon.js';
import { computeRegionMissionMetrics, cosIncidence } from './missionMetrics.js';
import { computeLocalizedSlopeAt, getElevationAt } from './terrain.js';
import { REGIONS } from '../regions.js';
import { LunarNavigatorScene } from './scene.js';
import { LunarNavigatorUI } from './ui.js';
import { makeUserPointRegion } from './pickPoint.js';
import { loadConfiguredDem } from './demLoader.js';

export class ArtemisNavigatorApp {
  constructor() {
    this.lastTime = performance.now();
    this.slopeRadiusKm = 3.0;

    // Pre-warm horizon cache for all 9 regions in background
    prewarmRegionHorizonProfiles(REGIONS);

    this._init();
  }

  _init() {
    const root = document.getElementById('root') || document.body;

    // 1. Initialize UI Shell with callbacks
    this.ui = new LunarNavigatorUI({
      container: root,
      callbacks: {
        onSetViewMode: (mode) => {
          if (this.scene) {
            this.scene.setViewMode(mode);
          }
          this._onTimeUpdate(timeStore.getSimTime());
        },
        onSetCameraPreset: (preset) => {
          if (this.scene) {
            this.scene.setCameraPreset(preset);
          }
        },
        onSelectRegion: (reg) => {
          if (this.scene) {
            this.scene.selectRegion(reg);
          }
          this._onTimeUpdate(timeStore.getSimTime());
        },
        onDockPolarOverview: () => {
          if (this.scene) {
            this.scene.dockToPolarOverview();
          }
        },
        onSlopeRadiusChange: (radKm) => {
          this.slopeRadiusKm = radKm;
          this._onTimeUpdate(timeStore.getSimTime());
        },
        onToggleCommsRay: (visible) => {
          if (this.scene) {
            this.scene.setCommsRayVisible(visible);
          }
        },
        onToggleEarthGlobe: (visible) => {
          if (this.scene) {
            this.scene.setEarthGlobeVisible(visible);
          }
        },
        onToggleLayer: (id, visible) => {
          if (this.scene && id === 'sun') {
            this.scene.setSunVisible(visible);
          }
          if (this.scene && id === 'solarPanel') {
            this.scene.setSolarPanelVisible(visible);
          }
        },
        onPickPoint: (result) => this._handlePickedPoint(result),
        onClearPickedPoint: () => this._clearPickedPoint(),
      },
    });

    // 2. Initialize Three.js Scene with callbacks for region pin interactions
    const canvasContainer = document.getElementById('canvas-container');
    if (canvasContainer) {
      this.scene = new LunarNavigatorScene(canvasContainer, {
        onSelectRegion: (reg) => {
          if (this.ui) {
            this.ui.selectRegion(reg);
          }
          this._onTimeUpdate(timeStore.getSimTime());
        },
        onPinHover: (hoverData) => {
          if (this.ui) {
            this.ui.showPinTooltip(hoverData);
          }
        },
        onPickPoint: (result) => this._handlePickedPoint(result),
      });
    }

    // 3. Subscribe to timeStore: updates Orrery positions and UI telemetry
    this.unsubscribeTimeStore = timeStore.subscribe((simTime) => {
      this._onTimeUpdate(simTime);
    });

    // Initial update for default simTime
    this._onTimeUpdate(timeStore.getSimTime());

    // 4. Start Animation / Physics Tick Loop
    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  /** Form entry or terrain click: analyse an arbitrary point as a pseudo-region (never one of the 9) */
  _handlePickedPoint(result) {
    if (!result || !result.ok) {
      if (this.ui) this.ui.showPickMessage(result ? result.message : '');
      return;
    }
    const region = makeUserPointRegion(result.lat, result.lon);
    if (this.scene) {
      this.scene.setUserPin(region);
      this.scene.selectRegion(region);
    }
    if (this.ui) this.ui.setUserPoint(region);
    this._onTimeUpdate(timeStore.getSimTime());
  }

  _clearPickedPoint() {
    if (this.scene) this.scene.clearUserPin();
    const prev = this.ui ? this.ui.clearUserPoint() : null;
    if (this.scene && prev) this.scene.selectRegion(prev);
    this._onTimeUpdate(timeStore.getSimTime());
  }

  _onTimeUpdate(simTime) {
    const validDate = (simTime instanceof Date && !isNaN(simTime.getTime())) ? simTime : timeStore.getSimTime();
    const ephem = computeEphemeris(validDate);

    if (this.scene) {
      this.scene.updateSimulation(ephem);
    }

    if (this.ui) {
      this.ui.updateTelemetry(ephem);

      // Evaluate active region telemetry (Round 4 Metrics Engine)
      const region = this.ui.selectedRegion || REGIONS[2];
      const elevKm = getElevationAt(region.lat, region.lon);

      // Topocentric celestial directions
      const sunTopo = computeTopocentricHorizon(region.lat, region.lon, ephem.subSolarLat, ephem.subSolarLon, 149597870.7, elevKm);
      const earthTopo = computeTopocentricHorizon(region.lat, region.lon, ephem.subEarthLat, ephem.subEarthLon, ephem.earthDistanceKm, elevKm);

      // Horizon masking and extended disc integration (f_sun and f_earth)
      const occlusion = evaluateRegionCelestialOcclusion(region, sunTopo, earthTopo);

      // Localized slope statistics within adjustable radius (default 3.0 km)
      const slopeStats = computeLocalizedSlopeAt(region.lat, region.lon, this.slopeRadiusKm);

      // Round 8: Update direct-to-Earth comms ray line in 3D scene
      if (this.scene) {
        this.scene.updateCommsRay(region, earthTopo, occlusion.fEarth);
        this.scene.updateSunReadout(sunTopo, occlusion.fSun);
        this._updateSolarPanel(region, sunTopo, occlusion.sunMaskDeg);
      }

      this.ui.updateRegionTelemetry({
        region,
        elevKm,
        sunTopo,
        earthTopo,
        occlusion,
        slopeStats,
      });

      // Round 9: Update chart cursor position
      this.ui.updateChartCursor(timeStore.elapsedDays);
    }
  }

  /**
   * Phase 8: orientation = the region's best fixed tilt/azimuth (cached per region; one synodic month from the
   * epoch), or `this.manualPanel` = { tiltDeg, azimuthDeg } when Manual mode (Phase 9) sets it. Lit state is the
   * binary centre-point I(t) used by missionMetrics. Nothing here touches the ephemeris per frame.
   */
  _updateSolarPanel(region, sunTopo, sunMaskDeg) {
    if (!this.scene || !region) return;
    let panel = this.manualPanel || null;
    if (!panel) {
      const m = computeRegionMissionMetrics({
        regionId: region.id, lat: region.lat, lon: region.lon,
        elevationKm: getElevationAt(region.lat, region.lon),
        horizonProfile: getRegionHorizonProfile(region.id, region.lat, region.lon),
        startDate: timeStore.baseEpoch, mastHeightM: DEFAULT_MAST_HEIGHT_M,
      });
      panel = { tiltDeg: m.bestFixed.beta, azimuthDeg: m.bestFixed.az };
    }
    const illuminated = sunTopo.elevationDeg > sunMaskDeg ? 1 : 0;
    const cosInc = cosIncidence(sunTopo.elevationDeg, panel.tiltDeg, sunTopo.azimuthDeg, panel.azimuthDeg);
    this.scene.updateSolarPanel(region, panel, illuminated, cosInc, DEFAULT_MAST_HEIGHT_M);
  }

  _loop(now) {
    const deltaSeconds = Math.min((now - this.lastTime) / 1000, 0.1);
    this.lastTime = now;

    // Advance simulation time if playing
    timeStore.tick(deltaSeconds);

    requestAnimationFrame(this._loop);
  }
}

// Global bootstrap: the DEM must be loaded before anything samples terrain (mesh, horizons, slopes, banner)
async function boot() {
  await loadConfiguredDem();
  window.artemisApp = new ArtemisNavigatorApp();
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
